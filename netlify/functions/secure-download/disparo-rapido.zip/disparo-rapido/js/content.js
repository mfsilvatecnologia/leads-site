// Função para aguardar até que um elemento apareça no DOM
const awaitTagsLoading = async (selector) => {
    return new Promise((resolve) => {
        if (document.querySelector(selector)) {
            return resolve(true);
        }
        
        let timeInterval = setInterval(() => {
            if (document.querySelector(selector)) {
                clearInterval(timeInterval);
                return resolve(true);
            }
        }, 1000);
    });
};

// Aguardar o carregamento completo da página
window.addEventListener('load', async () => {
    console.log('Página carregada completamente');
    
    // Inicializar o banco de dados
    try {
        console.log('Verificando se o banco de dados já está inicializado...');
        if (typeof window.db === 'undefined' || window.db === null) {
            console.log('Banco de dados não inicializado, tentando inicializar...');
            if (typeof window.initDatabase === 'function') {
                await window.initDatabase();
                console.log('Banco de dados inicializado com sucesso');
            } else {
                console.error('Função initDatabase não encontrada');
            }
        } else {
            console.log('Banco de dados já inicializado');
        }
    } catch (error) {
        console.error('Erro ao inicializar banco de dados:', error);
    }
});


// Função auxiliar para ler arquivo CSV
async function readCSVFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = (event) => {
            try {
                const content = event.target.result;
                const lines = content.split('\n');
                const contacts = [];
                
                for (let i = 0; i < lines.length; i++) {
                    const line = lines[i].trim();
                    if (!line) continue;
                    
                    const parts = line.split(',');
                    if (parts.length >= 2) {
                        const name = parts[0].trim();
                        const phone = parts[1].trim();
                        const message = parts.slice(2).join(',').trim();

                        if (phone) {
                            contacts.push({ name, phone, message });
                        }
                    }
                }
                
                resolve(contacts);
            } catch (error) {
                console.error('Erro ao processar arquivo:', error);
                reject(error);
            }
        };
        
        reader.onerror = () => {
            console.error('Erro ao ler arquivo');
            reject(new Error('Erro ao ler arquivo'));
        };
        
        reader.readAsText(file);
    });
}

// Exportar funções auxiliares para o escopo global
window.saveLicenseInfo = saveLicenseInfo;
window.readCSVFile = readCSVFile;
