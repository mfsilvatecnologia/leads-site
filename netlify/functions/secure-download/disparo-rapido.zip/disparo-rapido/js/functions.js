const FREE_MESSAGE_LIMIT = 10;

function showCustomModalMessage(title, message, type = 'info') {
    const existingModal = document.getElementById('customModalMessage');
    if (existingModal) {
        existingModal.remove();
    }

    const modal = document.createElement('div');
    modal.id = 'customModalMessage';
    modal.style.position = 'fixed';
    modal.style.left = '50%';
    modal.style.top = '20px';
    modal.style.transform = 'translateX(-50%)';
    modal.style.padding = '20px';
    modal.style.borderRadius = '8px';
    modal.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
    modal.style.zIndex = '10000'; // Ensure it's on top
    modal.style.textAlign = 'center';
    modal.style.maxWidth = '90%';
    modal.style.minWidth = '300px';

    let backgroundColor = '#f0f0f0'; // Default for info
    let textColor = '#333';

    if (type === 'error') {
        backgroundColor = '#f8d7da'; // Light red
        textColor = '#721c24';       // Dark red
    } else if (type === 'success') {
        backgroundColor = '#d4edda'; // Light green
        textColor = '#155724';       // Dark green
    } else if (type === 'warning') {
        backgroundColor = '#fff3cd'; // Light yellow
        textColor = '#856404';       // Dark yellow
    }

    modal.style.backgroundColor = backgroundColor;
    modal.style.color = textColor;
    modal.style.border = `1px solid ${textColor}`;

    const titleElement = document.createElement('h4');
    titleElement.textContent = title;
    titleElement.style.marginTop = '0';
    titleElement.style.marginBottom = '10px';

    const messageElement = document.createElement('p');
    messageElement.textContent = message;
    messageElement.style.marginBottom = '0';

    modal.appendChild(titleElement);
    modal.appendChild(messageElement);

    document.body.appendChild(modal);

    setTimeout(() => {
        if (document.getElementById('customModalMessage')) {
            document.getElementById('customModalMessage').remove();
        }
    }, 5000); // Auto-dismiss after 5 seconds
}

const formatNumber = (number) => {
  // número = +5599999999999
  const cleaned = ('' + number).replace(/\D/g, '');
  // número = 5599999999999
  const match = cleaned.match(/^(\d{2})(\d{2})(\d{4}|\d{5})(\d{4})$/);
  // número = 55 99 99999 9999
  if (match) {
    return ['(', match[2], ') ', match[3], '-', match[4]].join('');
  }
  // número = (99) 99999-9999
  return '';
};

const moreMessage = () => {
  let numberElement = document.querySelectorAll(
    'div[class*="m3ss4g3-"]'
  ).length;
  let div = document.createElement('div');
  div.classList.add('m3ss4g3', `m3ss4g3-${numberElement}`);

  div.innerHTML += `
    <div class="m3ss4g3-type">
      <div class="m3ss4g3-${numberElement}-type">
        <textarea
          class="form-control"
          placeholder="Olá [nome], tudo bem?"
          rows="2"
        ></textarea>
      </div>
    </div>

    <div class="buttons">
      <button
        id="m3ss4g3-${numberElement}-type"
        onclick="changeType('.m3ss4g3-${numberElement}-type')"
      >
        <i
          class="fa-regular fa-file"
          title="Trocar tipo da mensagem"
        ></i>
      </button>

      <button onclick="removeElement('.m3ss4g3-${numberElement}')">
      <i class="fa-solid fa-minus"></i>
      </button>
    </div>
    `;

  document.querySelector('#m3ss4g3s').appendChild(div);
};

const removeElement = (indentify) => {
  document.querySelector(indentify).remove();
};

const changeType = (indentify) => {

  let btnIcon = indentify.replace('.', '#');

  if (document.querySelector(indentify).innerHTML.includes('textarea')) {
    document.querySelector(
      indentify
    ).innerHTML = `<input type="file" id="filezim" class="form-control" id="">`;
    document.querySelector(`${btnIcon}`).innerHTML =
      '<i class="fa-regular fa-message" title="Trocar para Arquivos"></i>';
    id = 'm3ss4g3-${numberElement}-type';
  } else {
    document.querySelector(
      indentify
    ).innerHTML = `<textarea name="" cols="30" class="form-control" 
        placeholder="Olá [nome], tudo bem?"></textarea>`;
    document.querySelector(`${btnIcon}`).innerHTML =
      '<i class="fa-regular fa-file" title="Trocar para Mensagem"></i>';
  }
};

const sleep = (time) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve();
    }, time);
  });
};

const awaitTags = async () => {
  return new Promise((resolve) => {
    let timeInterval = setInterval(() => {
      if (
        document.querySelector(
          '.tvf2evcx.m0h2a7mj.lb5m6g5c.j7l1k36l.ktfrpxia.nu7pwgvd.p357zi0d.dnb887gk.gjuq5ydh.i2cterl7.fhf7t426.sap93d0t.r6jd426a.niluw8xz'
        )
      ) {
        clearInterval(timeInterval);
        return resolve('number_not_found');
      } else if (document.querySelector('button[data-tab="11"]')) {
        clearInterval(timeInterval);
        return resolve('send');
      }
    }, 1000);
  });
};

const readerCSV = (csv) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      resolve(e.target.result.replaceAll(';',','));
    };

    reader.onerror = (e) => {
      reject(`couldn't read csv`);
    };

    reader.readAsText(csv);
  });
};

const createLink = (num, text) => {
  let link;
  if (!document.querySelector('#vamos')) {
    link = document.createElement('a');
    link.id = 'vamos';
  } else {
    link = document.querySelector('#vamos');
  }

  link.href = `https://web.whatsapp.com/send/?phone=${num}&text=${text}`;
  document.querySelector('body').appendChild(link);
  document.querySelector('#vamos').click();
};

const typeFileSend = (message) => {
  if (message.mimetype.includes('image')) {
    return {
      type: 'image',
      // caption: 'My image', // Optional
      // isViewOnce: true
    };
  } else if (message.mimetype.includes('audio')) {
    return {
      type: 'audio',
      isPtt: true, // false for common audio
    };
  } else if (message.mimetype.includes('video')) {
    return {
      type: 'video',
    };
  } else {
    return {
      type: 'document',
      // caption: message.file.name, // Optional
      filename: message.file.name, // Optional
      mimetype: message.mimetype, // Optional
    };
  }
};

// number, message, waitTyping, contact
const check = async (num, message, waitSend, contact) => {
  if (message.type == 'text') {
    let messageText = message.text;
    messageText = messageText.replace('[nome]', contact.name);
    if (contact.message) {
      messageText = messageText.replace('[mensagem]', contact.message);
    }
    createLink(num, messageText);
  } else {
    createLink(num, '');
  }

  await sleep(waitSend);

  let sent = await awaitTags();

  // se modal de numero invalido tiver aberto
  if (sent == 'number_not_found') {
    return 'number_not_found';
  } else if ('send') {
    // numero encontrado envia msg
    if (message.type == 'file') {
      let contact = `${num}@c.us`;
      await WPP.chat.markIsRecording(contact, waitSend);
      await WPP.chat.sendFileMessage(
        contact,
        message.file,
        typeFileSend(message)
      );
    } else {
      document.querySelector('button[data-tab="11"]').click();
    }
    return 'send';
  }
};

const textNumberInvalid = (num) => {
  return `${num} \n`;
};

const textNumberValid = (num) => {
  return `${num} \n`;
};

const separeteMessage = (messages) => {
  let messageSequence = [];

  for (let message of messages) {
    if (message.querySelector('input')) {
      let file = message.querySelector('input').files[0];
      if (file)
        messageSequence.push({ file, mimetype: file.type, type: 'file' });
    } else if (message.querySelector('textarea')) {
      let messageText = message.querySelector('textarea').value;
      if (messageText != '')
        messageText = messageText.replaceAll('\n', '%0A')
        messageSequence.push({ type: 'text', text: messageText });
    }
  }

  return messageSequence;
};

// Função única para gravar contato no localStorage (últimos envios) e no IndexedDB
const saveContactRecord = async (num, nome = '', status = 'no') => {
    try {
        // Garantir que o banco está inicializado
        if (typeof window.initDatabase === 'function') {
            await window.initDatabase();
        } else {
            throw new Error('Funções do banco não estão disponíveis');
        }

        // Salvar no localStorage
        let storeName = 'lastNumberSend';
        let lastNumberSend = localStorage.getItem(storeName);
        let lastNumberSendArray = lastNumberSend ? lastNumberSend.split(',') : [];

        // Controla máximo de 3 últimos números
        if (lastNumberSendArray.length > 2) {
            lastNumberSendArray.pop();
        }
        lastNumberSendArray.unshift(num);
        localStorage.setItem(storeName, lastNumberSendArray);
        
        if (document.querySelector('.lastNumberSend')) {
            document.querySelector('.lastNumberSend').value = lastNumberSendArray;
        }

        // Salvar no IndexedDB
        if (typeof window.addContact === 'function') {
            await window.addContact(num, nome, status);
        } else {
            throw new Error('Função addContact não está disponível');
        }
    } catch (e) {
        console.error('Erro ao gravar contato:', e);
        throw e; // Re-lança o erro para tratamento superior
    }
};

const lastNumberSendElement = document.querySelector('.lastNumberSend');
if (lastNumberSendElement) {
  lastNumberSendElement.value = localStorage.getItem('lastNumberSend');
}
// document.querySelector(
//   '.myNumber'
// ).innerHTML = `<label>Número conectado:</label> ${formatNumber(
//   WPP.conn.getMyUserId().user
// )}`;

// --- Bloco 1: Adiciona mensagem na div .myNumber ---
var myNumberElement = document.querySelector('.myNumber');
if (myNumberElement) {
  myNumberElement.innerHTML = `Clique no botão Iniciar para habilitar o campo de licença`;
}

// --- Bloco 2: Evento para input de arquivo ---
const fileInput = document.querySelector('#file');
if (fileInput) {
  fileInput.addEventListener('change', async () => {
    const divPrincipal = document.querySelector('.popuprec');
    if (!divPrincipal) return;
    const fileCSV = fileInput.files[0];
    if (!fileCSV) return;
    const textCSV = await readerCSV(fileCSV);
    const contactsInput = divPrincipal.querySelector('#contacts');
    if (contactsInput) {
      contactsInput.value = textCSV;
    }
  });
}

// --- Bloco 3: Importa contatos do grupo ativo no WhatsApp ---
const importGroupContactsBtn = document.querySelector('#importGroupContacts');
if (importGroupContactsBtn) {
  importGroupContactsBtn.addEventListener('click', async () => {
    try {
      const chat = await WPP.chat.getActiveChat();
      if (!chat || !chat.id || !chat.groupMetadata) {
        alert('Este recurso só funciona dentro de um grupo.');
        return;
      }
      const participants = await WPP.group.getParticipants(chat.id._serialized || chat.id);
      const lines = participants.map(p => {
        const name = p.contact?.name || p.contact?.pushname || '';
        const phone = p.id?.user || p.id;
        return `${name},${phone}`;
      });
      const textarea = document.querySelector('#contacts');
      if (textarea) textarea.value = lines.join('\n');
    } catch (e) {
      console.error('Erro ao importar contatos do grupo:', e);
      alert('Não foi possível importar os contatos do grupo.');
    }
  });
}

// --- Bloco 4: Evento do botão de iniciar envio ---
const btnIniciarSend = document.querySelector('.btniniciarsend');
if (btnIniciarSend) {
  btnIniciarSend.addEventListener('click', async () => {
    const divPrincipal = document.querySelector('.popuprec');
    if (!divPrincipal) return;
    myNumberElement = document.querySelector('.myNumber');
    if (myNumberElement) {
      let userId;
      try {
        // Verificação mais robusta do WPPConnect
        if (typeof WPP !== 'undefined' && 
            WPP.conn && 
            typeof WPP.conn.getMyUserId === 'function' &&
            WPP.isReady && 
            (WPP.isAuthenticated === true || WPP.isAuthenticated === undefined)) {
          
          console.log('WPP está pronto, tentando obter ID do usuário...');
          userId = WPP.conn.getMyUserId();
          
        } else {
          console.warn('WPP não está totalmente inicializado. Estados:', {
            WPP_exists: typeof WPP !== 'undefined',
            conn_exists: typeof WPP !== 'undefined' && !!WPP.conn,
            getMyUserId_exists: typeof WPP !== 'undefined' && !!WPP.conn && typeof WPP.conn.getMyUserId === 'function',
            isReady: typeof WPP !== 'undefined' && WPP.isReady,
            isAuthenticated: typeof WPP !== 'undefined' && WPP.isAuthenticated
          });
          throw new Error('WPP não está totalmente inicializado');
        }
      } catch (e) {
        console.error('Erro ao obter o número do usuário:', e);
        // Mock para teste quando WPP não estiver pronto
        userId = { user: '16991039375' };
      }
      
      if (userId && userId.user) {
        myNumberElement.innerHTML = `<label>Número conectado:</label> ${formatNumber(userId.user)}`;
        console.log('Número conectado:', formatNumber(userId.user));
      } else {
        myNumberElement.innerHTML = '<span style="color:red">Número não disponível</span>';
      }
    }

    let messages = divPrincipal.querySelector('#m3ss4g3s');
    let messageSequence = separeteMessage(messages.children);
    const ativarLicenca = document.getElementById('license-section');

    let contacts = divPrincipal.querySelector('#contacts').value;
    contacts = contacts.trim().split('\n');
    let totalContacts =
      contacts.length == 1 ? (contacts[0] == '' ? 0 : 1) : contacts.length;

    // let message = divPrincipal.querySelector('#m3ss4g3').value
    let btnSend = divPrincipal.querySelector('.btniniciarsend');

    let divSent = divPrincipal.querySelector('#sent');
    let divNotSent = divPrincipal.querySelector('#notsent');
    let divProgressBar = divPrincipal.querySelector('.progressrc');
    let progressBar = divPrincipal.querySelector('.progress-bar');
    const alertDiv = document.getElementById('license-alert');
    progressBar.style.width = `0%`;

    divSent.innerHTML = '';
    divNotSent.innerHTML = '';

    // validando
    if (messageSequence.length <= 0) return alert('Sem mensagem');
    // TODO: ajustando regra para mostrar seção licença
    // if (totalContacts <= 0) return alert('Sem contato(s)');
    ativarLicenca.style.display = 'block';
    // Buscar a contagem de mensagens enviadas no IndexedDB
    let mensagensEnviadas = await getMessagesSentCount();
    // Verificar se há licença válida
    let temLicencaValida = await (typeof window.checkLicenseValidity === 'function' ? window.checkLicenseValidity() : false);

// Incrementa e persiste o total de mensagens enviadas no IndexedDB (stats)
async function incrementMessagesSentOnStats() {
  try {
    if (!window.db) {
      if (typeof window.initDatabase === 'function') {
        await window.initDatabase();
      } else {
        throw new Error('Banco de dados não inicializado');
      }
    }
    return new Promise((resolve, reject) => {
      try {
        // Busca o último registro de stats
        const transaction = window.db.transaction(['stats'], 'readwrite');
        const store = transaction.objectStore('stats');
        const index = store.index('messagesSent');
        const request = index.openCursor(null, 'prev');
        request.onsuccess = event => {
          let cursor = event.target.result;
          let currentTotal = 0;
          let idToUpdate = null;
          if (cursor) {
            currentTotal = cursor.value.messagesSent || 0;
            idToUpdate = cursor.value.id;
          }
          // Atualiza ou cria novo registro
          const newTotal = currentTotal + 1;
          if (idToUpdate) {
            store.put({ ...cursor.value, messagesSent: newTotal, date: new Date().toISOString() });
          } else {
            store.add({ messagesSent: newTotal, date: new Date().toISOString() });
          }
          resolve(newTotal);
        };
        request.onerror = event => {
          reject(event.target.error);
        };
      } catch (error) {
        reject(error);
      }
    });
  } catch (error) {
    console.error('Erro ao incrementar mensagens enviadas no stats:', error);
    return null;
  }
}


    if (totalContacts > 0) {
      let enviados = 1;
      divProgressBar.hidden = false;
      divPrincipal.querySelector('#progressMessage').innerHTML = 'Enviando...';
      while (contacts.length > 0) {
        let contact = contacts[0];
        // Sempre buscar o valor atualizado do banco antes de cada envio
        mensagensEnviadas = await getMessagesSentCount();
        temLicencaValida = await (typeof window.checkLicenseValidity === 'function' ? window.checkLicenseValidity() : false);
        // Só aplica o limite se NÃO houver licença válida
        if (!temLicencaValida && mensagensEnviadas >= FREE_MESSAGE_LIMIT) {
          alertDiv.style.display = 'block';
          alertDiv.innerText = `Você atingiu o limite gratuito de ${FREE_MESSAGE_LIMIT} mensagens. Adquira uma licença para continuar enviando.`;
          showCustomModalMessage(
            'Limite atingido',
            `Você atingiu o limite gratuito de ${FREE_MESSAGE_LIMIT} mensagens. Adquira uma licença para continuar enviando.`,
            'warning'
          );
          btnSend.disabled = false;
          break;
        }
        
        let waitContact = divPrincipal.querySelector('#waitContact').value * 1000;
        let waitTyping = divPrincipal.querySelector('#waitTyping').value * 1000;

        if (divPrincipal.querySelector('#pauserc').checked) {
          alert('envio pausado');
          btnSend.disabled = false;
          break;
        }
        btnSend.disabled = true;

        let parts = contact.split(',');
        contact = {
          name: parts[0].trim(),
          phone: parts[1].trim(),
          message: parts.slice(2).join(',').trim(),
        };
        try {
          let result = await WPP.contact.queryExists(
            `${contact.phone.trim()}@c.us`
          );
          await sleep(1000);

          if (result != undefined) {
            let number = result?.wid?.user;
            let sent;
            for (let message of messageSequence) {
              sent = await check(number, message, waitTyping, contact);
              mensagensEnviadas++;
              try {
                await incrementMessagesSentOnStats();
              } catch (e) {
                console.error('Erro ao persistir mensagens enviadas no stats:', e);
              }
            }
            if (sent == 'send') {
                divSent.innerHTML += textNumberValid(contact.phone);
                // Registrar o envio com sucesso no IndexedDB
                try {
                  await saveContactRecord(contact.phone.trim(), contact.name.trim(), 'yes');
                } catch (e) {
                  console.error('Erro ao gravar contato enviado:', e);
                }
              } else if (sent == 'number_not_found') {
                divNotSent.innerHTML += textNumberInvalid(contact.phone);
                // Registrar tentativa de envio com número inválido
                  try {
                  await saveContactRecord(contact.phone.trim(), contact.name.trim(), 'no');
                  } catch (e) {
                  console.error('Erro ao gravar contato não enviado:', e);
                }
              }
            } else {
              divNotSent.innerHTML += textNumberInvalid(contact.phone);
              try {
                await saveContactRecord(contact.phone.trim(), contact.name.trim(), 'no');
              } catch (e) {
                console.error('Erro ao gravar contato não enviado:', e);
              }
            }
          } catch (error) {
            divNotSent.innerHTML += textNumberInvalid(contact.phone);
            try {
              await saveContactRecord(contact.phone.trim(), contact.name.trim(), 'no');
            } catch (e) {
              console.error('Erro ao gravar contato com falha:', e);
            }
          }
          // inserir função para atualizar licença
          await preencherDadosLicencaUI();
        
        contacts.shift();
        divPrincipal.querySelector('#contacts').value = contacts.join('\n');

        progressBar.innerText = `${enviados} de ${totalContacts}`;
        progressBar.style.width = `${(enviados * 100) / totalContacts}%`;
        enviados += 1;
        await sleep(waitContact);
      }
      btnSend.disabled = false;
      document.getElementById('progressMessage').innerHTML = 'Finalizado';
    }

  });
}
