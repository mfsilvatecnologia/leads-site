// Funções de licenciamento
const API_URL = 'https://webhook.segurosdecarro.com.br/webhook/validate-license';

// Verificar se o banco de dados está inicializado
function checkDatabaseInitialized() {
    if (typeof window.db === 'undefined' || window.db === null) {
        console.error('Banco de dados não inicializado em license.js');
        return false;
    }
    return true;
}

// Garantir que o banco de dados esteja inicializado
async function ensureDatabase() {
    if (!checkDatabaseInitialized()) {
        console.log('Banco de dados não inicializado em license.js, tentando inicializar...');
        if (typeof window.initDatabase === 'function') {
            try {
                await window.initDatabase();
                console.log('Banco de dados inicializado com sucesso em license.js');
                return true;
            } catch (error) {
                console.error('Erro ao inicializar banco de dados em license.js:', error);
                return false;
            }
        } else {
            console.error('Função initDatabase não encontrada em license.js');
            return false;
        }
    }
    return true;
}

// Função para validar licença com o servidor
async function validateLicenseWithServer(licenseCode, whatsappNumber) {
    try {
        // Garantir que o banco de dados esteja inicializado
        await window.ensureDatabaseInitialized();
        if (!checkDatabaseInitialized()) {
            throw new Error('Banco de dados não inicializado');
        }
        
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                whatsappNumber,
                licenseCode
            })
        });
        
        if (!response.ok) {
            console.log("Erro na validação Licença", response)
            throw new Error(`Erro na validação: ${response.status}`);
        }
        const licenseData = await response.json();
        console.log("Retorno da API de Licenciamento", licenseData)
        
        // Corrigir: só invalida se o número for realmente diferente
        if (!licenseData.isValid) {
            // Apenas bloqueia a extensão, não o WhatsApp
            licenseData.isValid = false;
            console.log("licenseData - ERROR", licenseData.error)
            // licenseData.error = 'Licença inválida, verifique o código ou entre em contato com o suporte.  ';
            // licenseData.error += '  Se o erro permanecer você precisa remover a extenção Disparo Rápido e atualizar a página';
            // licenseData.error += licenseData;
        }
        // Se isValid for false, a extensão não injeta funcionalidades, mas o WhatsApp permanece funcionando normalmente

        if (licenseData.isValid) {
            await saveLicenseInfo(Object.assign({}, licenseData, { whatsappNumber, licenseCode }));
        }

        return licenseData;
    } catch (error) {
        console.error("Erro ao validar licença:", error);
        return { isValid: false, error: error.message };
    }
}

// Obter número do WhatsApp logado
async function getLoggedWhatsAppNumber() {
    // Implementação para obter o número do WhatsApp logado
    const myNumberElement = document.querySelector('.myNumber');
    if (myNumberElement && myNumberElement.textContent) {
        // Extrai apenas os dígitos do número
        const onlyDigits = myNumberElement.textContent.replace(/\D/g, '');
        return onlyDigits;
    }
    
    // Caso não encontre, tenta buscar do banco de dados
    try {
        // Garantir que o banco de dados esteja inicializado
        await window.ensureDatabaseInitialized();
        if (!checkDatabaseInitialized()) {
            throw new Error('Banco de dados não inicializado');
        }
        
        const transaction = window.db.transaction(['license'], 'readonly');
        const store = transaction.objectStore('license');
        const request = store.get(1);
        
        return new Promise((resolve, reject) => {
            request.onsuccess = (event) => {
                const data = event.target.result;
                resolve(data?.whatsappNumber || '');
            };
            
            request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    } catch (error) {
        console.error("Erro ao obter número do WhatsApp:", error);
        return '';
    }
}

// Obter contagem de mensagens enviadas
async function getMessagesSentCount() {
    try {
        // Garantir que o banco de dados esteja inicializado
        await window.ensureDatabaseInitialized();
        if (!checkDatabaseInitialized()) {
            throw new Error('Banco de dados não inicializado');
        }
        
        const transaction = window.db.transaction(['stats'], 'readonly');
        const store = transaction.objectStore('stats');
        const index = store.index('messagesSent');
        const request = index.openCursor(null, 'prev');
        
        return new Promise((resolve, reject) => {
            let totalMessages = 0;
            
            request.onsuccess = (event) => {
                const cursor = event.target.result;
                if (cursor) {
                    totalMessages += cursor.value.messagesSent;
                    cursor.continue();
                } else {
                    resolve(totalMessages);
                }
            };
            
            request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    } catch (error) {
        console.error("Erro ao obter contagem de mensagens:", error);
        return 0;
    }
}

// Salvar informações da licença
async function saveLicenseInfo(licenseData) {
    try {
        // Garantir que o banco de dados esteja inicializado
        await window.ensureDatabaseInitialized();
        if (!checkDatabaseInitialized()) {
            throw new Error('Banco de dados não inicializado');
        }
        
        // Obter os dados necessários antes de iniciar a transação
        const whatsappNumber = licenseData.whatsappNumber || await getLoggedWhatsAppNumber();
        const messagesSent = licenseData.messagesSent || await getMessagesSentCount();
        
        // Dados da licença
        const licenseInfo = {
            id: 1,
            licenseCode: licenseData.licenseCode || '',
            whatsappNumber: whatsappNumber,
            messagesSent: messagesSent,
            maxMessages: licenseData.maxMessages || 0,
            expirationDate: licenseData.expirationDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
            isValid: licenseData.isValid || false,
            lastChecked: new Date().toISOString()
        };
        
        // Agora iniciamos a transação depois de ter todos os dados
        return new Promise((resolve, reject) => {
            try {
                const transaction = window.db.transaction(['license'], 'readwrite');
                const store = transaction.objectStore('license');
                
                // Adicionar evento de conclusão da transação
                transaction.oncomplete = () => {
                    console.log('Transação de licença concluída com sucesso');
                    resolve(true);
                };
                
                transaction.onerror = (event) => {
                    console.error('Erro na transação de licença:', event.target.error);
                    reject(event.target.error);
                };
                
                // Salvar no banco
                const request = store.put(licenseInfo);
                
                request.onerror = (event) => {
                    console.error('Erro ao salvar licença:', event.target.error);
                    reject(event.target.error);
                };
            } catch (error) {
                console.error('Erro ao criar transação:', error);
                reject(error);
            }
        });
    } catch (error) {
        console.error("Erro ao salvar informações da licença:", error);
        return false;
    }
}

// Mostrar mensagem de licença inválida
function showLicenseInvalidMessage() {
    const container = document.querySelector('.popuprec > div');
    if (container) {
        container.innerHTML = `
            <div class="p-5 text-center">
                <h3 class="text-white">Licença Inválida</h3>
                <p class="text-white">Sua licença expirou ou é inválida. Entre em contato com o suporte para renovar.</p>
                <button class="btn btn-light mt-3" onclick="window.location.reload()">Tentar Novamente</button>
            </div>
        `;
    }
}

// Expor funções para o escopo global
window.validateLicenseWithServer = validateLicenseWithServer;
window.getLoggedWhatsAppNumber = getLoggedWhatsAppNumber;
window.getMessagesSentCount = getMessagesSentCount;
window.saveLicenseInfo = saveLicenseInfo;
window.showLicenseInvalidMessage = showLicenseInvalidMessage;
window.preencherDadosLicencaUI = preencherDadosLicencaUI;
window.checkLicenseValidity = checkLicenseValidity;

// Mostrar aviso de poucas mensagens restantes
function showLowMessagesWarning(remaining) {
    const container = document.querySelector('.popuprec');
    if (container) {
        const warningDiv = document.createElement('div');
        warningDiv.className = 'alert alert-warning mt-3 text-center';
        warningDiv.innerHTML = `Atenção: Restam apenas ${remaining} mensagens em sua licença.`;
        
        container.appendChild(warningDiv);
        
        // Remover após 10 segundos
        setTimeout(() => {
            warningDiv.remove();
        }, 10000);
    }
}

async function checkLicenseValidity() {
  try {
    await window.ensureDatabaseInitialized();
    const transaction = window.db.transaction(["license"], "readonly");
    const store = transaction.objectStore("license");
    const request = store.get(1);

    return new Promise((resolve) => {
      request.onsuccess = (event) => {
        const data = event.target.result;
        resolve(data?.isValid === true);
      };
      request.onerror = () => resolve(false);
    });
  } catch (error) {
    console.error("Erro ao verificar validade da licença:", error);
    return false;
  }
}


async function preencherDadosLicencaUI() {
    try {
        console.log('Preenchendo dados da licença na UI...');
        await window.ensureDatabaseInitialized();
        
        return new Promise((resolve, reject) => {
            try {
                const transaction = window.db.transaction(['license'], 'readonly');
                const store = transaction.objectStore('license');
                const request = store.get(1);
                
                request.onsuccess = (event) => {
                    try {
                        const data = event.target.result;
                        console.log('Dados da licença recuperados:', data);
                        
                        // if (!data) {
                        //     console.log('Nenhum dado de licença encontrado');
                        //     resolve(false);
                        //     return;
                        // }
                        
                        const title = document.getElementById('license-title');
                        const dataDiv = document.getElementById('license-data');
                        const input = document.getElementById('licenseCode');
                        const button = document.getElementById('authenticateBtn');
                        const section = document.getElementById('license-section');
                        const btnIniciarsend = document.getElementById('btnIniciarsend');
                            // Adicionar event listener ao botão de autenticação
                            if (button) {
                                button.onclick = async function() {
                                    button.disabled = true;
                                    const alertDiv = document.getElementById('license-alert');
                                    if (alertDiv) {
                                        alertDiv.style.display = 'none';
                                        alertDiv.innerText = '';
                                    }
                                    let licenseCode = input.value.trim();
                                    // Buscar número do WhatsApp conectado
                                    let whatsappNumber = '';
                                    try {
                                        if (typeof window.getLoggedWhatsAppNumber === 'function') {
                                            whatsappNumber = await window.getLoggedWhatsAppNumber();
                                            console.log('Número do WhatsApp conectado:', whatsappNumber);
                                        }
                                    } catch (e) {
                                        whatsappNumber = '';
                                    }
                                    if (!licenseCode || !whatsappNumber) {
                                        if (alertDiv) {
                                            alertDiv.style.display = 'block';
                                            alertDiv.style.color = 'red';
                                            alertDiv.innerText = 'Clique primeiro em Iniciar e depois Preencha a chave de licença e clique em Ativar Licença.';
                                            section.style.display = 'none';
                                            btnIniciarsend.innerHTML = 'Ativar Sistema';
                                        }
                                        button.disabled = false;
                                        return;
                                    }
                                    // Chama validação
                                    if (typeof window.validateLicenseWithServer === 'function') {
                                        const result = await window.validateLicenseWithServer(licenseCode, whatsappNumber);
                                        if (alertDiv) {
                                            alertDiv.style.display = 'block';
                                            if (result.isValid) {
                                                alertDiv.style.color = 'green';
                                                alertDiv.innerText = 'Licença ativada com sucesso!';
                                                // Opcional: esconder seção de licença após sucesso
                                                setTimeout(() => {
                                                    const section = document.getElementById('license-section');
                                                    if (section) section.style.display = 'none';
                                                    alertDiv.style.display = 'none';
                                                }, 2000);
                                            } else {
                                                alertDiv.style.color = 'red';
                                                alertDiv.innerText = result.error || 'Licença inválida.';
                                                section.style.display = 'block';
                                            }
                                        }
                                    }
                                    button.disabled = false;
                                };
                            }
                        
                        // Preencher campos com dados ou vazio
                        input.value = data?.licenseCode || '';
                        input.readOnly = false;
                        button.style.display = 'block';
                        // button.disabled = false;
                        if (!data) {
                            console.log('Nenhum dado de licença encontrado');
                            // Mostra campos vazios e botão
                            if (title) title.innerText = 'Insira a chave de licença';
                            if (dataDiv) dataDiv.innerHTML = `
                            <strong>Expiração:</strong> ${data?.expirationDate ? new Date(data.expirationDate).toLocaleDateString('pt-BR') : 'Teste Grátis - 10 Mensagens'}
                            `;
                        } else {
                            console.log('Dados de licença encontrados');
                            // Preencher dados, manter campos editáveis
                            if (title) {
                                title.innerText = 'Dados da licença atual';
                                title.style.color = 'black';
                            }
                            if (dataDiv) {
                                dataDiv.innerHTML = `
                                    <strong>Licença para o número:</strong> ${data.whatsappNumber || '-'} - 
                                    <strong>Expiração:</strong> ${data.expirationDate ? new Date(data.expirationDate).toLocaleDateString('pt-BR') : '-'}
                                `;
                            }
                        }
                        resolve(true);
                    } catch (innerError) {
                        console.error('Erro ao preencher dados da licença na UI:', innerError);
                        resolve(false);
                    }
                };
                
                request.onerror = (event) => {
                    console.error('Erro ao buscar dados da licença:', event.target.error);
                    reject(event.target.error);
                };
            } catch (transactionError) {
                console.error('Erro na transação do banco de dados:', transactionError);
                reject(transactionError);
            }
        });
    } catch (error) {
        console.error('Erro geral ao preencher dados da licença:', error);
        return false;
    }
}
  