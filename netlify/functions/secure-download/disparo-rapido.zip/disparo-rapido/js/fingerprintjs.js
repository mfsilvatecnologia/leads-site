function generateUUID() {
    let uuid = '';
    const characters = 'abcdef0123456789';
    const segments = [4, 4]; // Número de caracteres em cada segmento
    for (let i = 0; i < segments.length; i++) {
        for (let j = 0; j < segments[i]; j++) {
            uuid += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        if (i < segments.length - 1) {
            uuid += '-';
        }
    }
    return uuid;
}

const start = () => {
    //console.log('exec 2.0');
    if (localStorage.getItem('uid')) {
        return localStorage.getItem('uid')
    }
    let uid = generateUUID()
    localStorage.setItem('uid', uid)
    return uid
}

start()