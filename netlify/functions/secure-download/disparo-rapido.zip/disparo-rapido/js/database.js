// Configuração do IndexedDB
const DB_NAME = 'disparo_rapido_extension';
const DB_VERSION = 2; // Aumentado para garantir atualização de schema
let db;

// Inicialização do banco de dados
function initDatabase() {
    return new Promise((resolve, reject) => {
        // Verificar se o IndexedDB está disponível no navegador
        if (!window.indexedDB) {
            const error = new Error("Seu navegador não suporta IndexedDB. Algumas funcionalidades podem não funcionar corretamente.");
            console.error(error);
            reject(error);
            return;
        }

        try {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            
            request.onerror = (event) => {
                console.error("Erro ao abrir o banco de dados:", event.target.error);
                reject(event.target.error);
            };
            
            request.onsuccess = (event) => {
                db = event.target.result;
                window.db = db; // Expor globalmente
                
                // Configurar manipulador de erros para detectar problemas no banco
                db.onerror = (event) => {
                    console.error("Erro no banco de dados:", event.target.error);
                };
                
                resolve(db);
            };
            
            request.onupgradeneeded = (event) => {
                db = event.target.result;
                
                // Criar object stores necessárias
                if (!db.objectStoreNames.contains('contacts')) {
                    const contactsStore = db.createObjectStore('contacts', { keyPath: "phone" });
                    contactsStore.createIndex('sent', 'sent', { unique: false });
                    contactsStore.createIndex('date', 'date', { unique: false });
                    contactsStore.createIndex('name', 'name', { unique: false });
                    console.log("Store 'contacts' criada");
                }
                
                // Store para licenciamento
                if (!db.objectStoreNames.contains('license')) {
                    const licenseStore = db.createObjectStore('license', { keyPath: "id" });
                    licenseStore.createIndex('licenseCode', 'licenseCode', { unique: false });
                    licenseStore.createIndex('whatsappNumber', 'whatsappNumber', { unique: false });
                    licenseStore.createIndex('messagesSent', 'messagesSent', { unique: false });
                    licenseStore.createIndex('expirationDate', 'expirationDate', { unique: false });
                    licenseStore.createIndex('isValid', 'isValid', { unique: false });
                    console.log("Store 'license' criada");
                }
                
                // Store para estatísticas
                if (!db.objectStoreNames.contains('stats')) {
                    const statsStore = db.createObjectStore('stats', { keyPath: "id", autoIncrement: true });
                    statsStore.createIndex('date', 'date', { unique: false });
                    statsStore.createIndex('messagesSent', 'messagesSent', { unique: false });
                    console.log("Store 'stats' criada");
                }
            };
        } catch (error) {
            console.error("Erro inesperado ao inicializar banco de dados:", error);
            reject(error);
        }
    });
}

// Função para garantir que o banco está inicializado
async function ensureDatabaseInitialized() {
    try {
        if (typeof window.db === 'undefined' || window.db === null) {
            await initDatabase();
            return window.db;
        }
        return window.db;
    } catch (error) {
        console.error("Erro ao garantir inicialização do banco de dados:", error);
        throw error;
    }
}

// Função para adicionar contato ao banco de dados
async function addContact(phone, name, sent = 'no') {
    try {
        await ensureDatabaseInitialized();
        
        return new Promise((resolve, reject) => {
            try {
                const transaction = db.transaction(['contacts'], 'readwrite');
                const store = transaction.objectStore('contacts');
                
                const contact = {
                    phone: phone,
                    name: name || '',
                    sent: sent,
                    date: new Date().toLocaleString()
                };
                
                const request = store.put(contact);
                
                request.onsuccess = (e) => {
                    console.log(`Contato inserido: ${phone}`);
                    resolve(`Contato inserido: ${phone}`);
                };
                
                request.onerror = (e) => {
                    console.error(`Erro ao inserir contato ${phone}:`, e.target.error);
                    reject(`Erro ao inserir contato: ${e.target.error}`);
                };
                
                transaction.oncomplete = () => {
                    console.log(`Transação completada para adicionar contato ${phone}`);
                };
                
                transaction.onerror = (e) => {
                    console.error(`Erro na transação ao adicionar contato ${phone}:`, e.target.error);
                    reject(`Erro na transação: ${e.target.error}`);
                };
            } catch (error) {
                console.error(`Erro inesperado ao adicionar contato ${phone}:`, error);
                reject(error);
            }
        });
    } catch (error) {
        console.error("Erro ao garantir inicialização do banco antes de adicionar contato:", error);
        throw error;
    }
}

// Função para obter todos os contatos
async function getContacts() {
    try {
        await ensureDatabaseInitialized();
        
        return new Promise((resolve, reject) => {
            try {
                const transaction = db.transaction(['contacts'], 'readonly');
                const store = transaction.objectStore('contacts');
                const request = store.getAll();
                
                request.onsuccess = (e) => {
                    console.log(`${e.target.result.length} contatos encontrados`);
                    resolve(e.target.result);
                };
                
                request.onerror = (e) => {
                    console.error("Erro ao obter contatos:", e.target.error);
                    reject(e.target.error);
                };
            } catch (error) {
                console.error("Erro inesperado ao obter contatos:", error);
                reject(error);
            }
        });
    } catch (error) {
        console.error("Erro ao garantir inicialização do banco antes de obter contatos:", error);
        throw error;
    }
}

// Função para atualizar status de envio de um contato
async function updateContactStatus(phone, sent) {
    try {
        await ensureDatabaseInitialized();
        
        return new Promise((resolve, reject) => {
            try {
                const transaction = db.transaction(['contacts'], 'readwrite');
                const store = transaction.objectStore('contacts');
                const request = store.get(phone);
                
                request.onsuccess = (e) => {
                    const contact = e.target.result;
                    if (contact) {
                        contact.sent = sent;
                        contact.date = new Date().toLocaleString();
                        const updateRequest = store.put(contact);
                        
                        updateRequest.onsuccess = () => {
                            console.log(`Status do contato ${phone} atualizado para ${sent}`);
                            resolve(true);
                        };
                        
                        updateRequest.onerror = (e) => {
                            console.error(`Erro ao atualizar status do contato ${phone}:`, e.target.error);
                            reject(e.target.error);
                        };
                    } else {
                        console.warn(`Contato não encontrado: ${phone}`);
                        reject(new Error(`Contato não encontrado: ${phone}`));
                    }
                };
                
                request.onerror = (e) => {
                    console.error(`Erro ao buscar contato ${phone}:`, e.target.error);
                    reject(e.target.error);
                };
            } catch (error) {
                console.error(`Erro inesperado ao atualizar status do contato ${phone}:`, error);
                reject(error);
            }
        });
    } catch (error) {
        console.error("Erro ao garantir inicialização do banco antes de atualizar status:", error);
        throw error;
    }
}


// Função para obter número do WhatsApp logado
async function getLoggedWhatsAppNumber() {
    try {
        await ensureDatabaseInitialized();
        
        const licenseInfo = await getLicenseInfo();
        if (licenseInfo && licenseInfo.whatsappNumber) {
            return licenseInfo.whatsappNumber;
        }
        
        return '';
    } catch (error) {
        console.error("Erro ao obter número do WhatsApp:", error);
        return '';
    }
}

// Garantir que as funções estão disponíveis globalmente
window.initDatabase = initDatabase;
window.ensureDatabaseInitialized = ensureDatabaseInitialized;
window.addContact = addContact;
window.getContacts = getContacts;
window.updateContactStatus = updateContactStatus;
window.getLoggedWhatsAppNumber = getLoggedWhatsAppNumber;