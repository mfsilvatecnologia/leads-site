async function initLoad(valid, whatsappNumber, token) {
  if (!!document.querySelector('.popuprec')) {
    document.querySelector('.popuprec').hidden = !document.querySelector('.popuprec').hidden;
    return;
  }

  const loadScripts = (array) => {
    array.forEach(item => {
      let script;
      let localInsert;
      if (item.includes('.js')) {
        script = document.createElement('script');
        script.src = chrome.runtime.getURL(item);
        localInsert = 'body';
      } else {
        script = document.createElement('link');
        script.rel = "stylesheet";
        script.href = chrome.runtime.getURL(item);
        localInsert = 'head';
      }

      const insert = document.querySelector(localInsert);
      insert.insertBefore(script, insert.firstChild);
    });
  };

  let popup = `
    <div class="popuprec">
      <!-- Topo com logo e seção de licença -->
      <div class="top">
        <div class="logo-container" style="text-align: center; margin-bottom: 10px;">
          <img src="${chrome.runtime.getURL('images/logo-horizontal.png')}" alt="Disparo Rápido Logo" style="width: 200px; height: 55px; display: inline-block;" />
        </div>
        <div id="license-section" style="margin-bottom: 10px; display: none;">
          <p id="license-title" style="color: red; font-weight: bold;">Insira a chave de licença</p>
          <input type="text" id="licenseCode"
            placeholder="99999999-9999-9999-9999-999999999999"
            style="width: 100%; padding: 6px; margin-bottom: 5px; border: 1px solid #ccc; border-radius: 4px;" />
          <button id="authenticateBtn"
            style="width: 100%; padding: 6px; margin-bottom: 5px; border: none; border-radius: 4px; background-color: #25d366; color: white; cursor: pointer;">
            Ativar Licença
          </button>
          <div id="license-data" style="font-size: 13px; margin-top: 5px; color: black"></div>
        </div>
      </div>

      <div id="license-alert" style="color: red; font-weight: bold; display: none;"></div> <!-- Alerta de licença -->

      <!-- Conteúdo principal -->
      <div class="content">
        <div class="config">
          <p class="connected-number myNumber"><label>Nenhum número conectado</label></p><br />

          <div class="form-check form-switch" hidden>
            <input class="form-check-input" type="checkbox" id="pauserc">
            <label class="form-check-label" for="pauserc">Pausar</label>
          </div>

          <div class="form-group mt-3">
            <label for="contacts">Adicionar Contatos</label>
            <textarea class="form-control" id="contacts"
              placeholder="[nome],16999999999,[mensagem]"
              rows="3"></textarea>
          </div>

          <div class="form-group mt-3">
            <label for="file">Carregar Contatos</label>
            <input type="file" class="form-control" id="file" accept=".csv" />
          </div>
          <!-- vamos colocar o botão de importar grupos no mesmo estilo de carregar contatos -->
          <div class="form-group mt-3">
            <label for="importGroupContacts" id="importGroupContacts" class="btn btn-primary">
              Importar Contatos do Grupo
            </label>
          </div>

          <div class="form-group mt-3">
            <div class="input-interval">
              <label>Intervalo entre os disparos:</label>&nbsp;
              <input type="number" class="form-control" id="waitContact" value="70" min="1" max="999" />&nbsp;<p>segundos</p>
            </div>

            <div class="input-interval">
              <label>Tempo digitando:</label>&nbsp;
              <input type="number" class="form-control" id="waitTyping" value="5" min="1" max="999" />&nbsp;<p>segundos</p>
            </div>
          </div>

          <div class="form-group mt-3 m3ss4g3s-input">
            <label>Mensagem</label>
            <div id="m3ss4g3s">
              <div class="m3ss4g3 m3ss4g3-0">
                <div class="m3ss4g3-type">
                  <div class="m3ss4g3-0-type">
                    <textarea class="form-control" placeholder="Olá [nome], tudo bem?" rows="2">Olá [nome], tudo bem? [mensagem]</textarea>
                  </div>
                </div>

                <div class="buttons">
                  <button id="m3ss4g3-0-type" onclick="changeType('.m3ss4g3-0-type')">
                    <i class="fa-regular fa-file" title="Trocar tipo da mensagem"></i>
                  </button>
                  <button onclick="moreMessage()">
                    <i class="fa-solid fa-plus" title="Adicionar mensagem"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div class="mt-4 send">
            <button class="btniniciarsend"><p>Iniciar</p></button>
          </div>

          <div class="mt-4 progressrc" hidden>
            <div>
              <label id="progressMessage">Enviando</label>
              <div class="progress mt-2">
                <div class="progress-bar" role="progressbar" style="width: 0%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                  5 de 25
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="records">
          <div class="form-group">
            <label for="latest-num-sent">Últimos envios</label>
            <input id="latest-num-sent" class="lastNumberSend form-control" readonly />
          </div>

          <div class="shots row mt-3">
            <div class="form-group col-6">
              <label for="sent">Enviados</label>
              <textarea readonly class="form-control" id="sent"></textarea>
            </div>
            <div class="form-group col-6">
              <label for="notsent">Não Enviados</label>
              <textarea readonly class="form-control" id="notsent"></textarea>
            </div>
          </div>
        </div>
      </div>

      <div class="footer" style="text-align: center; margin-top: 20px; font-size: 10px; color: #6c757d;">
        <p>&copy; 2024 Disparo Rápido. Todos os direitos reservados.</p>
      </div>
    </div>
  `;

  if (document.querySelector('.popuprec')) {
    document.querySelector('.popuprec').remove();
  }

  loadScripts([
    "js/database.js",
    "js/license.js",
    "js/background.js",
    "js/content.js",
    "js/functions.js",
    "js/wppconnect-wa.js",
    "js/fingerprintjs.js",
    "css/bootstrap.min.css",
    "js/all.min.js"
  ]);

  const div = document.createElement('div');
  div.innerHTML = popup;
  document.querySelector('body').appendChild(div);

  // Aguardar um momento para garantir que os scripts foram carregados
  setTimeout(async () => {
    console.log('Tentando preencher dados da licença após criação da interface');
    if (typeof window.preencherDadosLicencaUI === 'function') {
      try {
        await window.preencherDadosLicencaUI();
        console.log('Dados da licença preenchidos com sucesso');
      } catch (error) {
        console.error('Erro ao preencher dados da licença:', error);
      }
    } else {
      console.error('Função preencherDadosLicencaUI não encontrada no objeto window');
    }
  }, 500); // Aguardar 500ms para garantir que os scripts foram carregados

}



const modifyHeaders = async (id, url) => {
  const rules = await chrome.declarativeNetRequest.getSessionRules();
  const removeRuleIds = rules.filter(rule => rule.condition.urlFilter === url).map(rule => rule.id);

  const addRules = [{
    id,
    action: {
      type: 'modifyHeaders',
      responseHeaders: [{ header: 'content-security-policy', operation: 'set', value: '' }]
    },
    condition: { urlFilter: url, resourceTypes: ['main_frame', 'sub_frame'] }
  }];

  chrome.browsingData.remove({}, { serviceWorkers: true }, () => {});
  await chrome.declarativeNetRequest.updateSessionRules({ addRules, removeRuleIds });
};

const openDatabase = () => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("whats-license", 1);

    request.onupgradeneeded = event => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains("license")) {
        db.createObjectStore("license", { keyPath: "key" });
      }
    };

    request.onsuccess = event => resolve(event.target.result);
    request.onerror = () => reject("Erro ao abrir o banco IndexedDB.");
  });
};

const getLicenseData = async () => {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("license", "readonly");
    const store = tx.objectStore("license");
    const request = store.get("data");

    request.onsuccess = () => resolve(request.result?.value || null);
    request.onerror = () => reject(null);
  });
};

const API_URL = 'https://webhook.segurosdecarro.com.br/webhook/validate-license';

async function validateLicense(token, whatsappNumber) {
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'token': token
      },
      body: JSON.stringify({ whatsappNumber })
    });

    if (!response.ok) throw new Error(`Erro na validação: ${response.status}`);

    return await response.json();
  } catch (error) {
    console.error("Erro ao validar licença:", error);
    return {
      isValid: false,
      message: `Erro ao validar licença: ${error.message}`
    };
  }
}

// Ação ao clicar no ícone da extensão
chrome.action.onClicked.addListener(async (tab) => {
  if (tab.url?.includes('whatsapp')) {
    await modifyHeaders(tab.id, tab.url);

    const licenseData = await getLicenseData();
    const token = licenseData?.licenseCode || ''; 
    const whatsappNumber = licenseData?.whatsappNumber || '';

    const isValid = !!(token && whatsappNumber);

    console.log("Token:", token);
    console.log("Número:", whatsappNumber);
    console.log("Válido:", isValid);

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: initLoad,
      args: [isValid, whatsappNumber, token]
    });
  }
});


// Atualiza headers se mudar de aba
chrome.tabs.onActivated.addListener(async () => {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (tab.url?.includes('whatsapp')) {
    await modifyHeaders(tab.id, tab.url);
  }
});

// Escuta mensagens de autenticação
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.command === 'login') {
    validateLicense(request.token, request.whatsappNumber).then(response => {
      sendResponse({
        command: 'login',
        status: response.isValid ? 'success' : 'danger',
        message: response.message || (response.isValid ? 'Licença válida!' : 'Licença inválida!'),
        expirationDate: response.expirationDate,
        maxMessages: response.maxMessages,
        messagesSent: response.messagesSent
      });
    }).catch(error => {
      sendResponse({
        command: 'login',
        status: 'danger',
        message: `Erro ao validar licença: ${error.message}`
      });
    });

    return true;
  }

  if (request.command === 'updateStats') {
    sendResponse({ success: true });
    return true;
  }

  return true;
});
